# Google Form Dashboard

Dashboard sederhana yang berfungsi sebagai pusat akses cepat ke beberapa Google Form dan Spreadsheet yang sering digunakan.

## 📁 Konten

- Monitoring Pending
- Monitoring Teknisi & Helper
- Bukti Pembayaran
- Pemakaian Refrigerant
- Surat Jalan

## 🚀 Teknologi

- HTML5
- CSS3 (tanpa framework)

## 📄 Lisensi

Proyek ini berlisensi [MIT](LICENSE).
